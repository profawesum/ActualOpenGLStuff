//#include "CubeMap.h"
//#include "camera.h"
//#include "ShaderLoader.h"
//#include "manager.h"
//
//#include <vector>
//#include <SOIL.h>
//
//#include "glm.hpp"
//#include "gtc/matrix_transform.hpp"
//#include "gtc/type_ptr.hpp"
//
//using namespace glm;
//
//using namespace std;
//
//
//camera cubeCam;
//
//GLuint skyBoxIndices[];
//
////GLfloat skyboxVertices[] = {
////	// Positions
////	-1.0f,  1.0f, -1.0f,
////	-1.0f, -1.0f, -1.0f,
////	1.0f, -1.0f, -1.0f,
////	1.0f, -1.0f, -1.0f,
////	1.0f,  1.0f, -1.0f,
////	-1.0f,  1.0f, -1.0f,
////
////	-1.0f, -1.0f,  1.0f,
////	-1.0f, -1.0f, -1.0f,
////	-1.0f,  1.0f, -1.0f,
////	-1.0f,  1.0f, -1.0f,
////	-1.0f,  1.0f,  1.0f,
////	-1.0f, -1.0f,  1.0f,
////
////	1.0f, -1.0f, -1.0f,
////	1.0f, -1.0f,  1.0f,
////	1.0f,  1.0f,  1.0f,
////	1.0f,  1.0f,  1.0f,
////	1.0f,  1.0f, -1.0f,
////	1.0f, -1.0f, -1.0f,
////
////	-1.0f, -1.0f,  1.0f,
////	-1.0f,  1.0f,  1.0f,
////	1.0f,  1.0f,  1.0f,
////	1.0f,  1.0f,  1.0f,
////	1.0f, -1.0f,  1.0f,
////	-1.0f, -1.0f,  1.0f,
////
////	-1.0f,  1.0f, -1.0f,
////	1.0f,  1.0f, -1.0f,
////	1.0f,  1.0f,  1.0f,
////	1.0f,  1.0f,  1.0f,
////	-1.0f,  1.0f,  1.0f,
////	-1.0f,  1.0f, -1.0f,
////
////	-1.0f, -1.0f, -1.0f,
////	-1.0f, -1.0f,  1.0f,
////	1.0f, -1.0f, -1.0f,
////	1.0f, -1.0f, -1.0f,
////	-1.0f, -1.0f,  1.0f,
////	1.0f, -1.0f,  1.0f
////};
////
////
//
//Cubemap::Cubemap(){
//
//}
//
//void Cubemap::loadTexture(){
//
//
//	glGenTextures(1, &texID);
//
//	int height, width;
//	unsigned char* image;
//
//	glBindTexture(GL_TEXTURE_CUBE_MAP, texID);
//
//	//creating the string of cubemap textures
//	vector<string> cubeMapTextures;
//
//	cubeMapTextures.push_back("Assets/Textures/CubeMap/right.jpg");
//	cubeMapTextures.push_back("Assets/Textures/CubeMap/left.jpg");
//	cubeMapTextures.push_back("Assets/Textures/CubeMap/top.jpg");
//	cubeMapTextures.push_back("Assets/Textures/CubeMap/bottom.jpg");
//	cubeMapTextures.push_back("Assets/Textures/CubeMap/back.jpg");
//	cubeMapTextures.push_back("Assets/Textures/CubeMap/front.jpg");
//
//	for (GLuint i = 0; i < 6; i++) {
//		string fullPathName = "Assets/Textures/CubeMap/";
//		fullPathName.append(cubeMapTextures[i]);
//
//		image = SOIL_load_image(fullPathName.c_str(), &width, &height, 0, SOIL_LOAD_RGBA);
//
//		glTexImage2D(GL_TEXTURE_CUBE_MAP_POSITIVE_X + i, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
//
//		SOIL_free_image_data(image);
//
//	}
//
//	glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
//	glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
//	glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
//	glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
//	glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_R, GL_CLAMP_TO_EDGE);
//
//	glGenerateMipmap(GL_TEXTURE_CUBE_MAP);
//	glBindTexture(GL_TEXTURE_CUBE_MAP, 0);
//
//	
//}
//
//void Cubemap::cubeMapUpdate(){
//
//	mat4 proj = perspective(45.0f, (float)manager::SCR_WIDTH / (float)manager::SCR_HEIGHT, 0.1f, 1000.0f);
//	glm::mat4 model = glm::scale(glm::mat4(), glm::vec3(2000.0f, 2000.0f, 2000.f));
//	//calculate the mvp matrix
//	MVP = proj * cubeCam.getView() * model;
//
//}
//
//
//void Cubemap::Render() {
//
//	glUseProgram(cubeProgram);
//	glEnable(GL_TEXTURE_CUBE_MAP_SEAMLESS);
//
//	loadTexture();
//
//	glActiveTexture(GL_TEXTURE0);
//	glBindTexture(GL_TEXTURE_CUBE_MAP, texID);
//	glUniform1i(glGetUniformLocation(cubeProgram, "cubeSampler"), 0);
//	glUniformMatrix4fv(glGetUniformLocation(cubeProgram, "MVP"), 1, GL_FALSE, glm::value_ptr(MVP));
//
//	glBindVertexArray(cubeVAO);
//	glDrawElements(GL_TRIANGLES, 36, GL_UNSIGNED_INT, 0);
//	glBindVertexArray(0);
//	glUseProgram(0);
//
//}
//
//void Cubemap::create(){
//
//
//
//	//vertcies
//	for (int i = 0; i < 8; i++)
//	{
//		if (i < 4)
//		{
//			CubeMapVertices[i * 3] = -1.0f;
//			for (int j = 0; j < 4; j++)
//			{
//				if (j < 2)
//				{
//					CubeMapVertices[(j * 3) + 1] = 1.0f;
//				}
//				else
//				{
//					CubeMapVertices[(j * 3) + 1] = -1.0f;
//				}
//
//				if (j % 2 == 0)
//				{
//					CubeMapVertices[(j * 3) + 2] = 1.0f;
//				}
//				else
//				{
//					CubeMapVertices[(j * 3) + 2] = -1.0f;
//				}
//			}
//		}
//		else
//		{
//			CubeMapVertices[i * 3] = 1.0f;
//			for (int j = 4; j < 8; j++)
//			{
//				if (j < 6)
//				{
//					CubeMapVertices[(j * 3) + 1] = 1.0f;
//				}
//				else
//				{
//					CubeMapVertices[(j * 3) + 1] = -1.0f;
//				}
//
//				if (j % 2 == 0)
//				{
//					CubeMapVertices[(j * 3) + 2] = 1.0f;
//				}
//				else
//				{
//					CubeMapVertices[(j * 3) + 2] = -1.0f;
//				}
//			}
//		}
//	}
//
//	GLuint temp[] = {
//		3,2,6,
//		3,6,7,
//
//		1,4,0,
//		1,5,4,
//
//		2,1,0,
//		2,3,1,
//
//		3,5,1,
//		3,7,5,
//
//		6,4,5,
//		6,5,7,
//
//		4,2,0,
//		4,6,2,
//
//	};
//
//	for (int i = 0; i < sizeof(temp); i++)
//	{
//		CubeMapIndices[i] = temp[i];
//	}
//
//	//creating the shaders
//	cubeProgram = ShaderLoader::CreateProgram("Assets/Shaders/CubeMap.vs", "Assets/Shaders/CubeMap.fs");
//	//add in the vertex array of positons
//	//create and assign vao, vbo and ebo
//
//	glGenVertexArrays(1, &cubeVAO);
//	glBindVertexArray(cubeVAO);
//
//	glGenBuffers(1, &cubeEBO);
//	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, cubeEBO);
//	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(CubeMapIndices), CubeMapIndices, GL_STATIC_DRAW);
//
//	glGenBuffers(1, &cubeVBO);
//	glBindBuffer(GL_ARRAY_BUFFER, cubeVBO);
//	//vertex array of position data
//	glBufferData(GL_ARRAY_BUFFER, sizeof(CubeMapVertices), CubeMapVertices, GL_STATIC_DRAW);
//
//
//	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (GLvoid*)0);
//	glEnableVertexAttribArray(0);
//
//
//
//
//
//}

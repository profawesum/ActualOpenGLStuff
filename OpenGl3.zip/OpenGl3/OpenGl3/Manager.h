#pragma once
#include <glew.h>
#include <freeglut.h>
#include <glm.hpp>
#include "gtc/type_ptr.hpp"




class manager
{
public:

	static const unsigned int SCR_WIDTH = 800;
	static const unsigned int SCR_HEIGHT = 800;


	GLfloat GetSCREEN_H();
	GLfloat GetSCREEN_W();
	void SetScreenDimentions(int axis, int size);

private:

	GLfloat SCREEN_H;
	GLfloat SCREEN_W;


};
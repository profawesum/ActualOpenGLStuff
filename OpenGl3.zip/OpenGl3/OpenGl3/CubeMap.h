//#pragma once
//
//#include <iostream>
//#include <vector>
//
//#include "glm.hpp"
//#include "gtc/matrix_transform.hpp"
//#include "gtc/type_ptr.hpp"
//
//#include <glew.h>
//#include <freeglut.h>
//
//using namespace std;
//using namespace glm;
//
//class Cubemap{
//public:
//
//	Cubemap();
//	void loadTexture();
//	void cubeMapUpdate();
//	void Render();
//	void create();
//
//private:
//
//
//	GLfloat CubeMapVertices[24] = {};
//	GLuint CubeMapIndices[36] = {};
//
//	GLuint texID;
//
//
//
//	//texturex6.push_back("right.jpg"); //right
//	//texturex6.push_back("left.jpg");    //left
//	//texturex6.push_back("top.jpg");    //top
//	//texturex6.push_back("bottom.jpg");    //botom
//	//texturex6.push_back("back.jpg");    //back
//	//texturex6.push_back("front.jpg");    //front
//
//
//
//	GLuint cubeProgram;
//
//
//	mat4 MVP;
//	GLuint cubeVAO;
//	GLuint cubeVBO;
//	GLuint cubeEBO;
//
//
//};
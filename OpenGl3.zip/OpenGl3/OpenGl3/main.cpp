

#include <glew.h>
#include <freeglut.h>
#include <SOIL.h>
#include <iostream>
#include <time.h>
#include <vector>
#include <windows.h>
#include <cstdlib>
#include <fmod.hpp>
#include "ShaderLoader.h"
#include "glm.hpp"
#include "gtc/matrix_transform.hpp"
#include "gtc/type_ptr.hpp"
#include "Audio.h"
#include "Input.h"
#include "ObjectManager.h"
#include "Camera.h"
#include "Manager.h"
#include "TextLabel.h"
#include "EnemyManager.h"
#include "CubeMap.h"


using namespace std;

ShaderLoader m_shader;

GLuint program = NULL;
GLuint programBG = NULL;
GLuint programe1 = NULL;
GLuint programe2 = NULL;
GLuint programCubeMap = NULL;



GLuint VBO;
GLuint VAO;
GLuint EBO;
GLuint VBObg;
GLuint VAObg;
GLuint EBObg;
GLuint VBOe1;
GLuint VAOe1;
GLuint EBOe1;
GLuint VBOcm;
GLuint VAOcm;
GLuint EBOcm;

GLuint texture;
GLuint texture1;
GLuint texturebg;
GLuint texturee1;

GLfloat currentTime;
GLfloat pasttime = 0;
GLfloat deltaTime;
GLfloat secondtimer;
int framecount = 0;
int fps = 0;


Audio1 audio;
Input input;
camera camera1;
ObjectManager objectmanager;
manager manager1;
EnemyManager enemymanager;
//Cubemap skyBox;
TextLabel label1; //score
TextLabel label2; //actual score
TextLabel label3; //menu
TextLabel label4; //sub menu
TextLabel label5; //deathscrenn
TextLabel label6; //win/loose
TextLabel label7; //level screen
TextLabel label8; //FPS



float TotalScore = 0.0f;
bool startplay = false;
bool restartplay = true;
int menuno = 0;
glm::mat4 proj;
bool winner = false;
int gameRound = 1;
float rotO = 0.0f;

glm::vec3 rotationAxisZ = glm::vec3(1.0f, 0.0f, 0.0f);
float rotationAngle = 0;
glm::mat4 rotationZ = glm::rotate(glm::mat4(), glm::radians(rotationAngle), rotationAxisZ);

//GLfloat vertices[]
//{	//pos                    //colour
//	-0.5f,	-0.5f,	0.0f,    0.0f, 0.0f, 1.0f,		0.0f, 1.0f,//bot left
//	0.5f,	0.5f,	0.0f,    1.0f, 0.0f, 0.0f,		1.0f, 0.0f,// top right
//	-0.5f,	0.5f,	0.0f,    0.0f, 1.0f, 0.0f,		0.0f, 0.0f, //top left
//	0.5f,	-0.5f,	0.0f,	 0.0f, 1.0f, 0.0f,		1.0f, 1.0f, //bot right
//};
//
//GLuint indices[] = 
//{
//	0,1,2,	//1 
//	0,3,1,	//2
//};

GLfloat vertices[] //player
{
	-1.0f, 0.0f, -0.5f,		0.0f, 1.0f, 0.0f,	0.0f, 1.0f,
	-1.0f, 0.0f, 0.5f,		0.0f, 1.0f, 0.0f,	0.0f, 0.0f,
	1.0f, 0.0f, 0.5f,		0.0f, 1.0f, 0.0f,	1.0f, 0.0f,
	1.0f, 0.0f, -0.5f,		0.0f, 1.0f, 0.0f,	1.0f, 1.0f,

	-1.0f, 0.0f, -0.5f,		0.0f, 1.0f, 0.0f,	1.0f, 1.0f,
	1.0f, 0.0f, -0.5f,		0.0f, 1.0f, 0.0f,	0.0f, 1.0f,

	1.0f, 0.0f, -0.5f,		0.0f, 1.0f, 0.0f,	1.0f, 1.0f,
	1.0f, 0.0f, 0.5f,		0.0f, 1.0f, 0.0f,	0.0f, 1.0f,

	1.0f, 0.0f, 0.5f,		0.0f, 1.0f, 0.0f,	1.0f, 1.0f,
	-1.0f, 0.0f, 0.5f,		0.0f, 1.0f, 0.0f,	0.0f, 1.0f,

	-1.0f, 0.0f, 0.5f,		0.0f, 1.0f, 0.0f,	1.0f, 1.0f,
	-1.0f, 0.0f, -0.5f,		0.0f, 1.0f, 0.0f,	0.0f, 1.0f,

	0.0f, 0.5f, 0.0f,		0.0f, 1.0f, 1.0f,	0.5f, 0.0f,
};

GLuint indices[] =
{
	1, 4, 3,
	1, 3, 2,

	4, 12, 5,
	6, 12, 7,
	8, 12, 9,
	10, 12, 11,

};

GLfloat vertices2[] //bg
{	//pos                    //colour
	-1.0f,	-1.0f,	1.0f,    0.0f, 0.0f, 1.0f,		0.0f, 1.0f,//bot left
	1.0f,	-1.0f,	-1.0f,    1.0f, 0.0f, 0.0f,		1.0f, 0.0f,// top right
	-1.0f,	-1.0f,	-1.0f,    0.0f, 1.0f, 0.0f,		0.0f, 0.0f, //top left
	1.0f,	-1.0f,	1.0f,	 0.0f, 1.0f, 0.0f,		1.0f, 1.0f, //bot right
};

GLuint indices2[] =
{
	0,1,2,	//1 
	0,3,1,	//2
};

GLfloat vertices3[] //enemie
{	//pos                    //colour
	-0.5f,	-0.5f,	0.0f,    0.0f, 0.0f, 1.0f,		0.0f, 1.0f,//bot left
	0.5f,	0.5f,	0.0f,    1.0f, 0.0f, 0.0f,		1.0f, 0.0f,// top right
	-0.5f,	0.5f,	0.0f,    0.0f, 1.0f, 0.0f,		0.0f, 0.0f, //top left
	0.5f,	-0.5f,	0.0f,	 0.0f, 1.0f, 0.0f,		1.0f, 1.0f, //bot right
};

GLuint indices3[] =
{
	0,1,2,	//1 
	0,3,1,	//2
};



bool checkCollision(glm::vec4 box1, glm::vec4 box2)
{
	bool collision = false;
	if ((box1.x > box2.x) && (box1.y < box2.x))
	{
		if ((box1.z < box2.z) && (box1.w > box2.z))
		{
			collision = true;
		}
		if ((box1.z < box2.w) && (box1.w > box2.w))
		{
			collision = true;
		}
	}
	if ((box1.x > box2.y) && (box1.y < box2.y))
	{
		if ((box1.z < box2.z) && (box1.w > box2.z))
		{
			collision = true;
		}
		if ((box1.z < box2.w) && (box1.w > box2.w))
		{
			collision = true;
		}
	}
	return(collision);
}

void Render()
{
	glClear(GL_DEPTH_BUFFER_BIT | GL_COLOR_BUFFER_BIT);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);


	if (input.CheckKeyDown('m') == true)
	{
		if (startplay == true)
		{
			audio.playSound(2);
			enemymanager.initializespeedanddir();
			objectmanager.initializeObjPos();
			enemymanager.initializeEPos();
			enemymanager.initializeE2Pos();
			gameRound = 3;
			startplay = false;
			restartplay = true;
			winner = false;
			menuno = 2;
		}
	}


	if (restartplay == true)
	{

		if (menuno == 0)
		{
			input.inputdelay(input);
			if (input.CheckKeyDown('o') == true && input.checkDownFirst(input, 'o') == true)
			{
				menuno = 1;
			}
			if (input.CheckKeyDown('p') == true)
			{
				gameRound = 1;
				enemymanager.initializespeedanddir();
				objectmanager.initializeObjPos();
				enemymanager.initializeEPos();
				enemymanager.initializeE2Pos();
				TotalScore = 0.0f;
				startplay = true;
				restartplay = false;
			}
			if (input.CheckKeyDown('q') == true)
			{
				glutLeaveMainLoop();
			}
			//label3.Render();
		}
		else if (menuno == 1)
		{
			//label4.Render();
			input.inputdelay(input);
			if (input.CheckKeyDown('o') == true && input.checkDownFirst(input, 'o') == true)
			{
				menuno = 0;
			}
		}
		else if (menuno == 2)
		{
			//game over
			//label5.Render();
			if (winner == false)
			{
				//label6.SetText("loser");
			}
			else
			{
				//label6.SetText("winner");
			}
			//label2.SetPosition(glm::vec2(-135.0f, 190.0f));
			//label6.Render();
			//label2.Render();
			//label2.SetPosition(glm::vec2(-400.0f, 300.0f));

			if (input.CheckKeyDown('o') == true)
			{
				menuno = 0;
			}

		}
		else if (menuno == 3)
		{
			//next round 
			/*label7.Render();
			label2.SetPosition(glm::vec2(-125.0f, 190.0f));
			label2.Render();
			label2.SetPosition(glm::vec2(-400.0f, 300.0f));*/
			if (input.CheckKeyDown('o') == true)
			{
				menuno = 0;
				startplay = true;
				restartplay = false;
			}
		}



	}


	if (startplay == true)
	{
		if (gameRound == 1)
		{


#pragma region "bg"

			camera1.calculate(currentTime);
			glm::vec3 backObjPosition = glm::vec3(0.0f, 0.0f, 0.0f);
			glm::mat4 backTranslationMatrix = glm::translate(glm::mat4(), backObjPosition);
			glm::vec3 objscaleBack = glm::vec3(2.0f, 2.0f, 2.0f);
			glm::mat4 scaleMatrixBack = glm::scale(glm::mat4(), objscaleBack);
			glm::mat4 backModel = backTranslationMatrix * rotationZ * scaleMatrixBack;
			glm::mat4 backProj_calc = proj * camera1.getView() * backModel;

			glUseProgram(programBG);

			GLuint mvpLoc2 = glGetUniformLocation(programBG, "proj_calc");
			glUniformMatrix4fv(mvpLoc2, 1, GL_FALSE, glm::value_ptr(backProj_calc));

			GLuint BackGroundLoc = glGetUniformLocation(programBG, "model");
			glUniformMatrix4fv(BackGroundLoc, 1, GL_FALSE, glm::value_ptr(backModel));

			glActiveTexture(GL_TEXTURE0);
			glBindTexture(GL_TEXTURE_2D, texturebg);
			glUniform1i(glGetUniformLocation(programBG, "tex"), 0);

			glBindVertexArray(VAObg);

			glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);
			glBindVertexArray(0);
			glUseProgram(0);

#pragma endregion 

#pragma region "player"
			glUseProgram(program);

			objectmanager.movement(audio, deltaTime, manager1.GetSCREEN_W(), manager1.GetSCREEN_H());
			camera1.calculate(currentTime);

			glm::vec3 objPosition = glm::vec3(0.5f, 0.5f, 0.0f);
			objPosition += objectmanager.GetObjectPos();
			glm::mat4 translationMatrix = glm::translate(glm::mat4(), objPosition);
			glm::vec3 objscale = glm::vec3(0.5f, 0.5f, 1.0f);
			glm::mat4 scaleMatrix = glm::scale(glm::mat4(), objscale);
			glm::mat4 model = translationMatrix * rotationZ * scaleMatrix;
			glm::mat4 mvp = proj * camera1.getView() * model;
			GLuint mvpLoc = glGetUniformLocation(program, "mvp");
			glUniformMatrix4fv(mvpLoc, 1, GL_FALSE, glm::value_ptr(mvp));
			GLuint modelLoc = glGetUniformLocation(program, "model");
			glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

			GLint currentTimeLoc = glGetUniformLocation(program, "currentTime");//gluint?
			glUniform1f(currentTimeLoc, currentTime);


			glActiveTexture(GL_TEXTURE0);
			glBindTexture(GL_TEXTURE_2D, texture);
			glUniform1i(glGetUniformLocation(program, "Tex"), 0);
			glActiveTexture(GL_TEXTURE1);
			glBindTexture(GL_TEXTURE_2D, texture1);
			glUniform1i(glGetUniformLocation(program, "Tex1"), 1);

			glBindVertexArray(VAO);
			glDrawElements(GL_TRIANGLES, sizeof(indices), GL_UNSIGNED_INT, 0);
#pragma endregion 

#pragma region "e1"

			enemymanager.Emovement(deltaTime, manager1.GetSCREEN_W(), manager1.GetSCREEN_H(), audio, 1);
			camera1.calculate(currentTime);
			glm::vec3 e1pos = glm::vec3(0.0f, 0.0f, 1.0f);
			e1pos += enemymanager.GetEPos();

			glm::mat4 e1TranslationMatrix = glm::translate(glm::mat4(), e1pos);
			glm::vec3 e1scale = glm::vec3(1.0f, 1.0f, 1.0f);
			glm::mat4 scaleMatrixe1 = glm::scale(glm::mat4(), e1scale);
			glm::mat4 e1Model = e1TranslationMatrix * rotationZ * scaleMatrixe1;
			glm::mat4 Proj_calc = proj * camera1.getView() * e1Model;



			glUseProgram(programe1);

			GLuint mvpLoc3 = glGetUniformLocation(programe1, "proj_calc");
			glUniformMatrix4fv(mvpLoc3, 1, GL_FALSE, glm::value_ptr(Proj_calc));
			GLuint modelLocEnemy1 = glGetUniformLocation(programe1, "model");
			glUniformMatrix4fv(modelLocEnemy1, 1, GL_FALSE, glm::value_ptr(e1Model));



			glActiveTexture(GL_TEXTURE0);
			glBindTexture(GL_TEXTURE_2D, texturee1);
			glUniform1i(glGetUniformLocation(programe1, "tex"), 0);

			glBindVertexArray(VAOe1);

			glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);
			glBindVertexArray(0);
			glUseProgram(0);

#pragma endregion 


//			skyBox.Render();



			glm::vec4 playerbox(objPosition.y, objPosition.y - objscale.y, objPosition.x, objPosition.x + objscale.x); //up down left right
			glm::vec4 enemybox(e1pos.y, e1pos.y - e1scale.y, e1pos.x, e1pos.x + e1scale.x);
			bool collision = false;
			//collision = checkCollision(playerbox, enemybox);

			if (collision == true)
			{
				audio.playSound(2);
				enemymanager.initializespeedanddir();
				objectmanager.initializeObjPos();
				enemymanager.initializeEPos();
				enemymanager.initializeE2Pos();
				gameRound = 3;
				startplay = false;
				restartplay = true;
				menuno = 3;
			}

			TotalScore = TotalScore + deltaTime;
			int displayScore = static_cast<int>(TotalScore);
			/*label2.SetText(to_string(displayScore));
			label1.Render();
			label2.Render();*/
		}


	}


	/*label8.SetText(to_string((fps)));
	label8.Render();*/

	glBindVertexArray(0);
	glUseProgram(0);

	glutSwapBuffers();
}

void Update()
{
	audio.update();
//	skyBox.cubeMapUpdate();

	currentTime = (GLfloat)glutGet(GLUT_ELAPSED_TIME);
	deltaTime = (currentTime - pasttime)* 0.1f;
	pasttime = currentTime;

	if (deltaTime > 0.0f)
	{
		secondtimer += deltaTime;
	}

	framecount++;

	if (secondtimer > 100.0f)
	{
		fps = framecount;
		framecount = 0;
		secondtimer = 0;
	}


	glutPostRedisplay();

}

int main(int argc, char **argv)
{
	manager1.SetScreenDimentions(1, 1280);
	manager1.SetScreenDimentions(2, 720);
	srand(static_cast <unsigned> (time(0)));
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGBA);
	glutInitWindowPosition(50, 50);


	glutInitWindowSize(static_cast<int>(manager1.GetSCREEN_W()), static_cast<int>(manager1.GetSCREEN_H()));
	glutCreateWindow("(0) : error C5145: must write to gl_Position");

	if (glewInit() != GLEW_OK)
	{
		cout << "somthin wrong cheif" << endl;
		system("pause");
	}

	// do this AFTER glewInit
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LESS);

	glEnable(GL_CULL_FACE);
	glCullFace(GL_BACK);
	glFrontFace(GL_CCW);



	float fullw = (float)manager1.GetSCREEN_W();
	float fulh = (float)manager1.GetSCREEN_H();
	proj = glm::perspective(45.0f, (float)fullw / (float)fulh, 0.1f, 1000.0f);

	glClearColor(1.0f, 0.3f, 0.3f, 1.0f);

	program = ShaderLoader::CreateProgram("shader.vs", "Assets/Shaders/BlingPhongShader.fs");
	programBG = ShaderLoader::CreateProgram("backG.vs", "Assets/Shaders/BlingPhongShader.fs");
	programe1 = ShaderLoader::CreateProgram("backG.vs", "Assets/Shaders/BlingPhongShader.fs");
	programe2 = ShaderLoader::CreateProgram("backG.vs", "Assets/Shaders/BlingPhongShader.fs");
	programCubeMap = ShaderLoader::CreateProgram("backG.vs", "Assets/Shaders/BlingPhongShader.fs");


//#pragma region "text"
//
//	label1 = TextLabel(manager1, "score:", "Assets/Fonts/arial.ttf", glm::vec2(-600.0f, 300.0f));
//	label2 = TextLabel(manager1, "", "Assets/Fonts/arial.ttf", glm::vec2(-400.0f, 300.0f));
//	label3 = TextLabel(manager1, R"(Robot Takes over 
//press p to play 
//press q to quit 
//
//	label5 = TextLabel(manager1, R"(Game over man, GAME OVER
//you are a 
//with a final score of
//1500+ to win
//press o to return to menu)", "Assets/Fonts/arial.ttf", glm::vec2(-600.0f, 300.0f));
//
//	label6 = TextLabel(manager1, "", "Assets/Fonts/arial.ttf", glm::vec2(-380.0f, 245.0f));
//	label7 = TextLabel(manager1, R"(you died
//try to do better in the next level
//your current score is 
//1500 score to win
//press o to start the next level)", "Assets/Fonts/arial.ttf", glm::vec2(-600.0f, 300.0f));
//	label8 = TextLabel(manager1, "", "Assets/Fonts/arial.ttf", glm::vec2(550.0f, 300.0f), glm::vec3(1.0f, 1.0f, 1.0f), 0.5f);
//
//#pragma endregion 

#pragma region "player"

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	glGenTextures(1, &texture);
	glBindTexture(GL_TEXTURE_2D, texture);

	int width, height;
	unsigned char* image = SOIL_load_image("Assets/Textures/Building.png", &width, &height, 0, SOIL_LOAD_RGBA);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
	glGenerateMipmap(GL_TEXTURE_2D);
	SOIL_free_image_data(image);
	glBindTexture(GL_TEXTURE_2D, 0);

	glGenTextures(1, &texture1);
	glBindTexture(GL_TEXTURE_2D, texture1);

	unsigned char* image2 = SOIL_load_image("Assets/Textures/Building.png", &width, &height, 0, SOIL_LOAD_RGBA);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image2);
	glGenerateMipmap(GL_TEXTURE_2D);
	SOIL_free_image_data(image2);
	glBindTexture(GL_TEXTURE_2D, 0);

	glGenVertexArrays(1, &VAO);
	glBindVertexArray(VAO);

	glGenBuffers(1, &EBO);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

	glGenBuffers(1, &VBO);
	glBindBuffer(GL_ARRAY_BUFFER, VBO);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, (8 * (sizeof(GLfloat))), (GLvoid*)0);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, (8 * (sizeof(GLfloat))), (GLvoid*)(3 * (sizeof(GLfloat))));
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, (8 * (sizeof(GLfloat))), (GLvoid*)(6 * (sizeof(GLfloat))));
	glEnableVertexAttribArray(2);

#pragma endregion 

#pragma region "bg"
	glGenTextures(1, &texturebg);
	glBindTexture(GL_TEXTURE_2D, texturebg);
	unsigned char* imagebg = SOIL_load_image("Assets/Textures/Space.jpg", &width, &height, 0, SOIL_LOAD_RGBA); //ass/pics/bruh.jpg
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, imagebg);

	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glGenerateMipmap(GL_TEXTURE_2D);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	SOIL_free_image_data(imagebg);
	glBindTexture(GL_TEXTURE_2D, 0);


	glGenVertexArrays(1, &VAObg);
	glBindVertexArray(VAObg);

	glGenBuffers(1, &EBObg);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBObg);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices2), indices2, GL_STATIC_DRAW);

	glGenBuffers(1, &VBObg);
	glBindBuffer(GL_ARRAY_BUFFER, VBObg);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices2), vertices2, GL_STATIC_DRAW);


	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (GLvoid*)0);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (GLvoid*)(3 * sizeof(GLfloat)));
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (GLvoid*)(6 * sizeof(GLfloat)));
	glEnableVertexAttribArray(2);

#pragma endregion 

#pragma region "enemie1"

	glGenTextures(1, &texturee1);
	glBindTexture(GL_TEXTURE_2D, texturee1);
	unsigned char* imagee1 = SOIL_load_image("Assets/Textures/EnemySpaceShip.png", &width, &height, 0, SOIL_LOAD_RGBA); //bazinga.jpg
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, imagee1);

	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glGenerateMipmap(GL_TEXTURE_2D);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	SOIL_free_image_data(imagee1);
	glBindTexture(GL_TEXTURE_2D, 0);


	glGenVertexArrays(1, &VAOe1);
	glBindVertexArray(VAOe1);

	glGenBuffers(1, &EBOe1);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBOe1);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices3), indices3, GL_STATIC_DRAW);

	glGenBuffers(1, &VBOe1);
	glBindBuffer(GL_ARRAY_BUFFER, VBOe1);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices3), vertices3, GL_STATIC_DRAW);


	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (GLvoid*)0);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (GLvoid*)(3 * sizeof(GLfloat)));
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (GLvoid*)(6 * sizeof(GLfloat)));
	glEnableVertexAttribArray(2);

#pragma endregion 


	camera1.initializeCamera();
	//audio.AudioInit();
	audio.Create("Assets/Sounds/takeonme2.mp3", 1);
	audio.Create("Assets/Sounds/oof.wav", 2);
	audio.Create("Assets/Sounds/bruh1.wav", 3);
	audio.playSound(1);

//	skyBox.create();

	//main loop
	glutDisplayFunc(Render);
	glutIdleFunc(Update);

	glutKeyboardFunc(Input::KeyboardDown);
	glutKeyboardUpFunc(Input::KeyboardUp);

	glutSpecialFunc(Input::specialCharDown);
	glutSpecialUpFunc(Input::specialCharUp);

	glutMainLoop();

	return 0;
}
